# Distributed Digital Transactions
## CA Project

Lecturer: 
  - Dr. Muhammad Iqbal

Group Members:
1. Xiaohui Weng 2020387 
2. Leisly Pino 2020303 
3. Thiago Santos 2020327
4. Eliabe Bali 2022474
5. Yuri Mendoca 2020347

[The exposition and explanation of this project are in this video.](https://drive.google.com/file/d/1vN_WH6wK6neZ3KcuBIRiUUMoYGul1jt6/view?usp=sharing)
